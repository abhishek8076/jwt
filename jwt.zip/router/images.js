const express = require('express');
const multer = require('multer');
const mongoose = require('mongoose');

const router = express.Router();
const verify = require("../jwt/verifyToken");

const app = express();
router.use(verify);

const storage = multer.diskStorage({
    desc: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    imageUrl: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    },
});

const upload = multer({ storage: storage });

router.post('/uploadimage', upload.single('desc'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'No image provided' });
    }

    const { title, desc } = req.body;
    const imageUrl = req.file.path;

    try {
        const newImage = new Image({ title, desc, imageUrl });
        await newImage.save();
        return res.status(200).json({ message: 'Image uploaded successfully' });
    } catch (error) {
        return res.status(500).json({ error: 'An error occurred while uploading the image' });
    }
});
router.get('/getimage',async (req,res)=>{
    try {
        const GetAllImages = await Image.find(req.body.id)

        res.status(201).json(GetAllImages)
   } catch (err) {
        res.status(500).json(err);
   }
})
router.delete('/:id', async (req, res) => {
    if (req.user.isAdmin) {
         try {
              const deleteImage = await Movies.findByIdAndDelete(req.param.id)

              res.status(201).json("This movie had been deleted",deleteImage)
         } catch (err) {
              res.status(500).json(err);
         }
    }
    else {
         res.status(403).json("You are not allowed !")
    }

});
module.exports = router;