const express = require("express");
const router = express.Router();
const Navmenu = require("../models/navmenu");
const verify = require("../jwt/verifyToken");


// UPDATE
router.put('/updatemenudata/:id', verify, async (req, res) => {
    try {
        const updateNavmenu = await Navmenu.findByIdAndUpdate(req.params.id,
            { $set: req.body },
            { new: true });
        res.status(200).json(updateNavmenu);
    } catch (err) {
        console.error(err);
        res.status(500).json(err);
    }
});

// DELETE
router.delete('/deletemenudata/:id', verify, async (req, res) => {
    try {
        await Navmenu.findByIdAndDelete(req.params.id);
        res.status(200).json("Navmenu deleted.");
    } catch (err) {
        console.error(err);
        res.status(500).json(err);
    }
});

// GET
router.get('/getmenudata/:id', async (req, res) => {
    try {
        const navmenu = await Navmenu.findById(req.params.id);
        const { ...info } = navmenu._doc;
        res.status(200).json(info);
    } catch (err) {
        console.error(err);
        res.status(500).json(err);
    }
});

// GET ALL
router.get('/getmenudata', async (req, res) => {
    try {
        const limit = req.query.limit || 10; // Use query parameter for limit
        const navmenu = await Navmenu.find().limit(limit);
        res.status(200).json(navmenu);
    } catch (err) {
        console.error(err);
        res.status(500).json(err);
    }
});
router.use((req, res) => {
    res.status(404).json("404 - Not Found");
})

module.exports = router;
